-- MySQL dump 10.13  Distrib 5.7.16, for Win64 (x86_64)
--
-- Host: localhost    Database: xuptmsgbook
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(45) NOT NULL,
  `upwd` varchar(45) NOT NULL,
  `upur` varchar(45) NOT NULL DEFAULT '10000',
  `name` varchar(45) DEFAULT NULL,
  `pic` varchar(160) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin@qq.com','21232f297a57a5a743894a0e4a801fc3','1000','aaa',NULL),(2,'guest@qq.com','21232f297a57a5a743894a0e4a801fc3','0100','bbb',NULL),(3,'aaa@qq.com','21232f297a57a5a743894a0e4a801fc3','0100000','小明','20190328194238237_607.jpg'),(4,'aaa@qq.com','21232f297a57a5a743894a0e4a801fc3','0100000','龙总',NULL),(5,'abc@qq.com','e10adc3949ba59abbe56e057f20f883e','0100000','xiaoxiao',NULL),(6,'123@qq.com','21232f297a57a5a743894a0e4a801fc3','0100000','hhh','20190328203252587_174.png'),(7,'wwh\'sfather@qq.com','e10adc3949ba59abbe56e057f20f883e','0100000','吴文马的爸爸','20190328203259171_241.jpg'),(8,'666@qq.com','202cb962ac59075b964b07152d234b70','0100000','龙总牛逼(喊破音)','20190328203306904_983.png'),(9,'hh@qq.com','e10adc3949ba59abbe56e057f20f883e','0100000','hh',NULL),(10,'151556@168.cn','21232f297a57a5a743894a0e4a801fc3','0100000','房总','20190328203329525_733.jpg'),(11,'laobiao@qq.com','e10adc3949ba59abbe56e057f20f883e','0100000','桂平的后裔','20190328203319766_75.jpg'),(12,'1111@gmail.com','e10adc3949ba59abbe56e057f20f883e','0100000','龙总','20190328203332812_216.jpg'),(13,'bbb@qq.com','202cb962ac59075b964b07152d234b70','0100000','meimei','20190328203343918_639.jpg'),(14,'123@zth.com','21232f297a57a5a743894a0e4a801fc3','0100000','南京的雨不停的下','20190328203402312_155.jpg'),(15,'123456@qq.com','d0dcbf0d12a6b1e7fbfa2ce5848f3eff','0100000','皮卡丘',NULL),(16,'555@qq.com','e10adc3949ba59abbe56e057f20f883e','0100000','龙总','20190328203404678_930.jpg'),(17,'88888888@qq.com','96e79218965eb72c92a549dd5a330112','0100000','xinglu','20190328203408251_934.png'),(18,'aaa@qq.com','250cf8b51c773f3f8dc8b4be867a9a02','0100000','ZXC',NULL),(19,'mashayan0236@gmail.com','e10adc3949ba59abbe56e057f20f883e','0100000','mars','20190328203430252_329.jpg'),(20,'xzyjsp@126.com','fb62579e990da4e2a8f15c3d1e123438','0100000','753951','20190328203444629_316.png'),(21,'1430182244@qq.com','ba73752bd29bc89cc4674678754d7d55','0100000','楠',NULL),(22,'666@qq.com','47bce5c74f589f4867dbd57e9ca9f808','0100000','小六','20190328203502803_727.jpg'),(23,'666@qq.com','e10adc3949ba59abbe56e057f20f883e','0100000','涛总大丑人','20190328203608203_455.jpg'),(24,'123456@163.com','e10adc3949ba59abbe56e057f20f883e','0100000','国家一级退堂鼓鼓手','20190328203612601_967.jpg'),(25,'1455031484@qq.com','21232f297a57a5a743894a0e4a801fc3','0100000','房总','20190328203627137_978.jpg'),(26,'1375747987@qq.com','21232f297a57a5a743894a0e4a801fc3','0100000','lisa','20190328203628245_88.jpg'),(27,'1455031484@qq.cn','21232f297a57a5a743894a0e4a801fc3','0100000','hhh','20190328204039385_786.exe');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `msg`
--

DROP TABLE IF EXISTS `msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `msg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `content` text NOT NULL,
  `ctime` datetime DEFAULT NULL,
  `admin_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `msg`
--

LOCK TABLES `msg` WRITE;
/*!40000 ALTER TABLE `msg` DISABLE KEYS */;
INSERT INTO `msg` VALUES (1,'这是第一条留言','这是是是是\r\n练手法要   \r\n 是是是是    是 国国\r\n 标杆','2019-03-28 20:18:29',3),(2,'第二第留刘加盟国是男是女','这是是是<br/>是是&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;国楞国<br/>&nbsp;楞另&nbsp;','2019-03-28 20:27:21',3),(3,'你好吗','<p><br/>	<span&nbsp;style=\"background-color:#9933E5;\">你好吗</span>？<br/></p><br/><p><br/>	步是<em>&nbsp;<span&nbsp;style=\"color:#9933E5;\">国国</span></em><br/></p><br/><p><br/>	架菲<strong>利克斯</strong>时<br/></p>','2019-03-28 20:30:16',3),(4,'龙总牛逼','龙总牛逼','2019-03-28 20:33:21',3),(5,'hhhh','<p>\r\n	<span style=\"color:#E56600;\">hhhhhhh</span>\r\n</p>\r\n<p>\r\n	<span style=\"background-color:#FF9900;\">aaaaaaaa</span>\r\n</p>\r\n<p>\r\n	<strong>asas&nbsp;&nbsp;</strong><em>dsdfe</em>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>','2019-03-28 20:33:51',6),(6,'悄咪咪问一句，龙总是真的牛逼吗？','龙总是真的牛逼（喊破音）<br />','2019-03-28 20:33:57',8),(7,'悄咪咪问一句，龙总是真的牛逼吗？','龙总是真的牛逼（喊破音）<br />','2019-03-28 20:34:00',8),(8,'哈喽','<span style=\"color:#E56600;\">很棒</span>','2019-03-28 20:34:03',5),(9,'悄咪咪问一句，龙总是真的牛逼吗？','龙总是真的牛逼（喊破音）<br />','2019-03-28 20:34:04',8),(10,'悄咪咪问一句，龙总是真的牛逼吗？','龙总是真的牛逼（喊破音）<br />','2019-03-28 20:34:07',8),(11,'老表','今天的你只管努力，其他交给天意','2019-03-28 20:34:31',11),(12,'在线等！！！！急！！！！跪求问吴文马是傻吊么','<strong><span style=\"color:#FFE500;\">请问请问！！！！！！求回答</span></strong>','2019-03-28 20:34:35',7),(13,'什么是皮卡丘','皮卡丘~','2019-03-28 20:34:59',15),(14,'是真的牛逼','顶顶顶','2019-03-28 20:35:01',16),(15,'hhhhh','hhhhhhhh','2019-03-28 20:35:03',18),(16,'吴文马牛逼+龙总牛皮','<p>\r\n	指数再次显示出显示出市场VS<span style=\"background-color:#009900;\"><strong></strong>上下车上车VS从</span>\r\n</p>\r\n<p>\r\n	<span style=\"background-color:#009900;\">闲杂想啊伤心啊超出市场的</span>\r\n</p>','2019-03-28 20:35:20',12),(17,'neinei','<strong>mingtianyijiushigehaorizi</strong>','2019-03-28 20:35:29',13),(18,'南京的雨不停的下不停的下','呼叫刘狗子，收到请回答','2019-03-28 20:36:02',14),(19,'hhhhh','哈哈哈','2019-03-28 20:36:20',20),(20,'嘿嘿嘿','斤<span style=\"background-color:#E56600;\">斤计较急</span>急<strong>急急急急急急</strong>急<span style=\"color:#E53333;\">急急急急急急</span>','2019-03-28 20:36:22',8),(21,'等一盅螺蛳粉','<span style=\"color:#E53333;background-color:#EE33EE;\">一个莫得感情的粉仔</span><span style=\"background-color:#E53333;\"><span style=\"color:#E53333;\"></span></span>','2019-03-28 20:36:24',11),(22,'嘿嘿嘿','斤<span style=\"background-color:#E56600;\">斤计较急</span>急<strong>急急急急急急</strong>急<span style=\"color:#E53333;\">急急急急急急</span>','2019-03-28 20:36:25',8),(23,'是真的牛逼','顶顶顶','2019-03-28 20:36:28',16),(24,'Carol','德累斯顿','2019-03-28 20:36:37',17),(25,'是真的牛逼','顶顶顶','2019-03-28 20:37:01',16),(26,'嘻嘻嘻','若不是你突然闯进我生活','2019-03-28 20:37:01',21),(27,'魔镜魔镜告诉我，涛总美丽不美丽','大美丽','2019-03-28 20:37:05',23),(28,'十九大精神','<p>\r\n	asdfasdf\r\n</p>\r\n<p>\r\n	<strong>哎浮动打死</strong>\r\n</p>\r\n<p>\r\n	<strong><span style=\"background-color:#FF9900;\">a士大夫撒旦</span><span style=\"color:#E56600;background-color:#FF9900;\"></span></strong>\r\n</p>','2019-03-28 20:37:05',26),(29,'刘老师帅吗','废话','2019-03-28 20:37:11',19),(30,'魔镜魔镜告诉我，涛总美丽不美丽','大美丽','2019-03-28 20:37:13',23),(31,'南京的雨不停的下不停的下','呼叫刘狗子，收到请回答','2019-03-28 20:37:32',14),(32,'南京的雨不停的下不停的下','呼叫刘狗子，收到请回答','2019-03-28 20:38:50',14),(33,'什么是虚拟仪器','是用户自定义的基于PC的测量和测试方案','2019-03-28 20:38:55',19),(34,'南京的雨不停的下不停的下','呼叫刘狗子，收到请回答','2019-03-28 20:39:06',14),(35,'若不是你','突然闯进我生活，我怎会把死守的寂寞放任了','2019-03-28 20:39:28',21),(36,'谁有腾讯视频VIP','跪求急急急！！！','2019-03-28 20:39:53',19),(37,'咱们什么时候下课','我饿了','2019-03-28 20:40:02',7),(38,'谁有腾讯视频VIP','找我mashaoyan0236@gmail.com','2019-03-28 20:40:37',19),(44,'吴文马牛逼+龙总牛皮','<p>\r\n	指数再次显示出显示出市场VS<span style=\"background-color:#009900;\"><strong></strong>上下车上车VS从</span>\r\n</p>\r\n<p>\r\n	<span style=\"background-color:#009900;\">闲杂想啊伤心啊超出市场的</span>\r\n</p>','2019-03-28 20:45:01',12),(45,'吴文马牛逼+龙总牛皮','<p>\r\n	指数再次显示出显示出市场VS<span style=\"background-color:#009900;\"><strong></strong>上下车上车VS从</span>\r\n</p>\r\n<p>\r\n	<span style=\"background-color:#009900;\">闲杂想啊伤心啊超出市场的</span>\r\n</p>','2019-03-28 20:45:03',12),(46,'吴文马牛逼+龙总牛皮123','<p>\r\n	指数再次显示出显示出市场VS<span style=\"background-color:#009900;\"><strong></strong>上下车上车VS从</span> \r\n</p>\r\n<p>\r\n	<span style=\"background-color:#009900;\">闲杂想啊伤心啊超出市场的123</span>\r\n</p>','2019-03-28 21:47:05',12),(48,'ddddddddddddddddddddd','ddddddddddddddddd','2019-03-28 21:56:08',1);
/*!40000 ALTER TABLE `msg` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-10 15:22:50
